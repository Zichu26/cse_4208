1. Zichu Pan
2. 
```
output:
BaseClass::BaseClass()
BaseClass::BaseClass()
DerivedClass::DerivedClass()
DerivedClass
BaseClass
BaseClass
DerivedClass::~DerivedClass()
BaseClass::~BaseClass()
BaseClass::~BaseClass()
```
```cpp
DerivedClass derived;
const std::string DerivedClass::* ptr_derived = &DerivedClass::derived_name;
const std::string DerivedClass::* ptr_base_from_derived = &DerivedClass::base_name;
const std::string BaseClass::* ptr_base = &BaseClass::base_name;
std::cout << derived.*ptr_derived << std::endl;
std::cout << derived.*ptr_base_from_derived << std::endl;
std::cout << base.*ptr_base << std::endl;

int success = 0;

return success;
```
3. 
```cpp
const std::string DerivedClass::* ptr_derived = DerivedClass::get_derived_name_ptr(); 
const std::string DerivedClass::* ptr_base_from_derived = BaseClass::get_base_name_ptr(); 
const std::string BaseClass::* ptr_base = BaseClass::get_base_name_ptr();
```
4. 
```output
BaseClass::BaseClass()
BaseClass::BaseClass()
DerivedClass::DerivedClass()
BaseClass::print()
DerivedClass::print()
DerivedClass::print()
DerivedClass::~DerivedClass()
BaseClass::~BaseClass()
BaseClass::~BaseClass()
```
```cpp
void (BaseClass::*ptr_base_func)() = &BaseClass::print;
void (DerivedClass::*ptr_derived_base_func)() = &BaseClass::print;
void (DerivedClass::*ptr_derived_func)() = &DerivedClass::print;

(base.*ptr_base_func)();
(derived.*ptr_derived_base_func)();
(derived.*ptr_derived_func)();
```
5. With virtual functions, the call uses dynamic dispatch - the actual function called is determined at runtime based on the actual type of the object (`derived` is a `DerivedClass`), so it calls the overridden version.
```
output:
BaseClass::BaseClass()
BaseClass::BaseClass()
DerivedClass::DerivedClass()
BaseClass::print()
BaseClass::print()
DerivedClass::print()
DerivedClass::~DerivedClass()
BaseClass::~BaseClass()
BaseClass::~BaseClass()
```
6. 
```cpp
std::function<void(BaseClass&)> func_base = &BaseClass::print;
std::function<void(DerivedClass&)> func_derived_base = &BaseClass::print;
std::function<void(DerivedClass&)> func_derived = &DerivedClass::print;
```
7. 
```cpp
auto func_base = std::mem_fn(&BaseClass::print); 
auto func_derived_base = std::mem_fn(&BaseClass::print); 
auto func_derived = std::mem_fn(&DerivedClass::print);
```