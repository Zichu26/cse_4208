#ifndef BASECLASS_H
#define BASECLASS_H

class BaseClass {
public:
    BaseClass();
    virtual ~BaseClass();
    virtual void print();
};

#endif