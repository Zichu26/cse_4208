#ifndef MYCLASS_H
#define MYCLASS_H

#include <string>

class MyClass {
private:
    std::string str;

public:
    MyClass() = default;
    MyClass(const std::string& s);
    MyClass(const MyClass& other);
    virtual ~MyClass();
    MyClass& operator=(const MyClass& other);
    virtual void print();
};

#endif